"""
Wrapper to run auto_search_main with local dataset patch.
Sources env variables first, then patches datasets.load_dataset,
then invokes the main entry point.
"""
import sys
import os

# Add LocAgent to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

# Apply the dataset patch BEFORE any other imports
import scripts.local_dataset_patch  # noqa: F401

# Now import and run the main module
from auto_search_main import main

if __name__ == '__main__':
    main()
