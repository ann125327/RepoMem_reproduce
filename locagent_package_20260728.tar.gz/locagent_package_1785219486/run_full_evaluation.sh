#!/bin/bash
# SWE-bench Verified完整评估脚本

# 设置环境变量
export LOCAL_DATASET_PATCH=true
export ANTHROPIC_API_KEY="${ANTHROPIC_API_KEY:-your_api_key_here}"

# 创建必要的目录
mkdir -p index_data/SWE-bench_Verified/graph_index_v2.3
mkdir -p index_data/SWE-bench_Verified/BM25_index
mkdir -p results/locagent_full_500

export GRAPH_INDEX_DIR=index_data/SWE-bench_Verified/graph_index_v2.3
export BM25_INDEX_DIR=index_data/SWE-bench_Verified/BM25_index

echo "开始LocAgent完整评估（500个实例）..."
echo "预计时间：6-10小时（首次运行需构建索引）"
echo "预计费用：\$600-900"

# 运行评估
python auto_search_main.py \
    --localize \
    --merge \
    --model anthropic/qwen-max \
    --dataset princeton-nlp/SWE-bench_Verified \
    --num_samples 500 \
    --output_folder results/locagent_full_500 \
    --max_attempt_num 1 \
    --num_processes 30 \
    --use_function_calling \
    --simple_desc

# 运行评估脚本
echo "生成评估报告..."
python scripts/evaluate_localization.py \
    results/locagent_full_500/loc_outputs.jsonl \
    hf_dataset_temp/data/test-00000-of-00001.parquet \
    results/locagent_full_500

echo "评估完成！"
echo "结果位置：results/locagent_full_500/"
