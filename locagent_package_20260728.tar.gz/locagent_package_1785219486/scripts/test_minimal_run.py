"""
Minimal test to verify LocAgent can run end-to-end on Windows.
Bypasses multiprocessing to isolate issues.
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

# Apply dataset patch
import scripts.local_dataset_patch

import time
import json
import logging
from datasets import load_dataset

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(filename)s %(levelname)s %(message)s")

# Step 1: Load dataset
print("=" * 60)
print("Step 1: Loading dataset...")
bench_data = load_dataset("princeton-nlp/SWE-bench_Verified", split="test")
print(f"Loaded {len(bench_data)} instances")
bug = bench_data[0]
print(f"First instance: {bug['instance_id']}")
print(f"Repo: {bug['repo']}")
print()

# Step 2: Set up the issue (clone repo)
print("=" * 60)
print("Step 2: Setting up issue (cloning repo)...")
from plugins.location_tools.repo_ops.repo_ops import set_current_issue, reset_current_issue
set_current_issue(instance_data=bug, rank=0)
print("Repo cloned and checked out")
print()

# Step 3: Build the prompt
print("=" * 60)
print("Step 3: Building prompt...")
from auto_search_main import get_task_instruction
from util.runtime import function_calling
from plugins import LocationToolsRequirement
from util.prompts.prompt import PromptManager

prompt_manager = PromptManager(
    prompt_dir=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'util', 'prompts'),
    agent_skills_docs=LocationToolsRequirement.documentation,
)

system_prompt = function_calling.SYSTEM_PROMPT
messages = [{"role": "system", "content": system_prompt}]
messages.append({"role": "user", "content": get_task_instruction(bug, include_pr=True, include_hint=True)})

tools = function_calling.get_tools(
    codeact_enable_search_keyword=True,
    codeact_enable_search_entity=True,
    codeact_enable_tree_structure_traverser=True,
    simple_desc=True,
)

print(f"System prompt length: {len(system_prompt)} chars")
print(f"User message length: {len(messages[-1]['content'])} chars")
print(f"Number of tools: {len(tools) if tools else 0}")
print()

# Step 4: Make API call (single turn, no loop)
print("=" * 60)
print("Step 4: Making API call...")
from auto_search_main import auto_search_process
from auto_search_main import auto_search_prompt as auto_search
import torch.multiprocessing as mp

ctx = mp.get_context('spawn')
result_queue = ctx.Manager().Queue()

proc = ctx.Process(target=auto_search_process, kwargs={
    'result_queue': result_queue,
    'model_name': 'qwen3.6-plus',
    'messages': messages,
    'fake_user_msg': auto_search.FAKE_USER_MSG_FOR_LOC,
    'temp': 1,
    'tools': tools,
    'use_function_calling': True,
})
proc.start()
print(f"Subprocess started (PID: {proc.pid})")
proc.join(timeout=300)

if proc.is_alive():
    print("Timeout! Terminating.")
    proc.terminate()
    proc.join()
else:
    print(f"Subprocess exited with code: {proc.exitcode}")
    try:
        result = result_queue.get_nowait()
        if isinstance(result, dict) and 'error' in result:
            print(f"Error: {result['error']}")
        else:
            loc_result, messages_out, traj_data = result
            print(f"Localization result: {loc_result[:200] if loc_result else 'EMPTY'}")
            print(f"Prompt tokens: {traj_data['usage']['prompt_tokens']}")
            print(f"Completion tokens: {traj_data['usage']['completion_tokens']}")
    except Exception as e:
        print(f"Failed to get result: {e}")

print()
print("=" * 60)
print("Cleanup...")
reset_current_issue()
print("Done!")
