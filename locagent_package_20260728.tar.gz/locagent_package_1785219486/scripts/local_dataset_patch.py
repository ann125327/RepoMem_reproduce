"""
Monkey-patch datasets.load_dataset to use local parquet files
when HuggingFace/Xet is unreachable.

Usage: import this module BEFORE any other LocAgent import.
"""
import os
import sys

# Ensure we can find local parquet files relative to the project root
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Map of HF dataset names to local parquet files
LOCAL_DATASET_MAP = {
    'princeton-nlp/SWE-bench_Verified': os.path.join(
        PROJECT_ROOT, '..', 'hf_dataset_temp', 'data', 'test-00000-of-00001.parquet'
    ),
}


def _apply_patch():
    """Apply the load_dataset monkey-patch."""
    import datasets
    original_load_dataset = datasets.load_dataset

    def patched_load_dataset(path, split=None, **kwargs):
        if path in LOCAL_DATASET_MAP:
            local_path = LOCAL_DATASET_MAP[path]
            if os.path.exists(local_path):
                print(f'*** LOCAL_DATASET_PATCH: loading "{path}" from local parquet: {local_path} ***')
                # Local parquet files always produce a 'train' split
                ds = datasets.load_dataset('parquet', data_files=local_path, split='train')
                print(f'*** LOCAL_DATASET_PATCH: loaded {len(ds)} instances ***')
                return ds
            else:
                print(f'*** LOCAL_DATASET_PATCH: local file not found at {local_path}, falling back to HF ***')
        return original_load_dataset(path, split=split, **kwargs)

    datasets.load_dataset = patched_load_dataset
    print('*** LOCAL_DATASET_PATCH applied: HF datasets will fall back to local parquet ***')


# Auto-apply on import
_apply_patch()
