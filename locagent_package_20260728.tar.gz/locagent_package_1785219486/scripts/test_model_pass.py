"""Test that model_name is correctly passed through spawn subprocess."""
import torch.multiprocessing as mp
import os
import sys

class Args:
    model = 'anthropic/qwen3.6-plus'
    use_function_calling = True
    simple_desc = True

def auto_search_test(result_queue, model_name):
    print(f'>>> CHILD received model_name="{model_name}"', flush=True)
    print(f'>>> CHILD ANTHROPIC_API_KEY set: {bool(os.environ.get("ANTHROPIC_API_KEY"))}', flush=True)

    # Try the actual litellm call
    import litellm
    try:
        response = litellm.completion(
            model=model_name,
            messages=[{'role': 'user', 'content': 'Say hello in one sentence.'}],
            max_tokens=50,
        )
        print(f'>>> CHILD got response: {response.choices[0].message.content[:50]}', flush=True)
        result_queue.put({'status': 'ok', 'content': response.choices[0].message.content})
    except Exception as e:
        print(f'>>> CHILD error: {e}', flush=True)
        result_queue.put({'status': 'error', 'message': str(e)})

if __name__ == '__main__':
    args = Args()
    ctx = mp.get_context('spawn')
    q = ctx.Manager().Queue()

    print(f'>>> PARENT spawning with model_name="{args.model}"', flush=True)
    p = ctx.Process(target=auto_search_test, kwargs={
        'result_queue': q,
        'model_name': args.model,
    })
    p.start()
    p.join(timeout=60)
    print(f'>>> PARENT child exit code: {p.exitcode}', flush=True)
    try:
        result = q.get_nowait()
        print(f'>>> PARENT result: {result}', flush=True)
    except Exception as e:
        print(f'>>> PARENT no result: {e}', flush=True)
