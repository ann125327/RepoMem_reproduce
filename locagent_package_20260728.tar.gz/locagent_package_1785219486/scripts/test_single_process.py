"""
Simplified single-process run to verify LocAgent works end-to-end on Windows.
Bypasses multiprocessing to focus on the core logic.
"""
import sys
import os
import time
import json
import logging

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

# Apply dataset patch
import scripts.local_dataset_patch

from datasets import load_dataset
from util.runtime import function_calling
from util.runtime.fn_call_converter import (
    convert_fncall_messages_to_non_fncall_messages,
    STOP_WORDS as NON_FNCALL_STOP_WORDS
)
from util.actions.action_parser import ResponseParser
from util.actions.action import ActionType, FinishAction, MessageAction, IPythonRunCellAction
from util.prompts.prompt import PromptManager
from plugins import LocationToolsRequirement
from plugins.location_tools.repo_ops.repo_ops import (
    set_current_issue, reset_current_issue,
)
from auto_search_main import get_task_instruction
from util.prompts.pipelines import auto_search_prompt as auto_search
import litellm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(filename)s %(levelname)s %(message)s")

# Load dataset
print("=" * 60)
print("Step 1: Loading dataset...")
bench_data = load_dataset("princeton-nlp/SWE-bench_Verified", split="test")
print(f"Loaded {len(bench_data)} instances")
bug = bench_data[0]
print(f"Instance: {bug['instance_id']}, Repo: {bug['repo']}")

# Setup issue (clone repo, build/load graph, load BM25)
print("\n" + "=" * 60)
print("Step 2: Setting up issue...")
set_current_issue(instance_data=bug, rank=0)
print("Issue setup complete (graph + BM25 loaded from cache)")

# Build prompt
print("\n" + "=" * 60)
print("Step 3: Building prompt and tools...")
system_prompt = function_calling.SYSTEM_PROMPT
messages = [{"role": "system", "content": system_prompt}]
messages.append({"role": "user", "content": get_task_instruction(bug, include_pr=True, include_hint=True)})

tools = function_calling.get_tools(
    codeact_enable_search_keyword=True,
    codeact_enable_search_entity=True,
    codeact_enable_tree_structure_traverser=True,
    simple_desc=True,
)

print(f"System prompt: {len(system_prompt)} chars")
print(f"User prompt: {len(messages[-1]['content'])} chars")
print(f"Tools: {len(tools)}")

# Run the agent loop (single process, no subprocess)
print("\n" + "=" * 60)
print("Step 4: Running agent loop (single process)...")

model_name = 'anthropic/qwen3.6-plus'
fake_user_msg = auto_search.FAKE_USER_MSG_FOR_LOC
parser = ResponseParser()
max_iterations = 20

for iteration in range(1, max_iterations + 1):
    print(f"\n--- Iteration {iteration} ---")

    # Convert messages for non-function-calling model
    converted_messages = convert_fncall_messages_to_non_fncall_messages(
        messages, tools, add_in_context_learning_example=False
    )

    try:
        response = litellm.completion(
            model=model_name,
            temperature=1.0, top_p=0.8, repetition_penalty=1.05,
            messages=converted_messages,
            stop=NON_FNCALL_STOP_WORDS,
        )
    except Exception as e:
        print(f"API error: {e}")
        break

    print(f"Response: {response.choices[0].message}")
    messages.append({"role": "assistant", "content": response.choices[0].message.content if response.choices[0].message.content else ""})

    actions = parser.parse(response)
    if not isinstance(actions, list):
        actions = [actions]

    for action in actions:
        if action.action_type == ActionType.FINISH:
            print(f"\n=== FINISH ===")
            print(f"Result: {action.thought[:500]}")
            # Save result
            output = {
                "instance_id": bug['instance_id'],
                "found_files": [[]],
                "found_modules": [[]],
                "found_entities": [[]],
                "raw_output_loc": [action.thought],
                "meta_data": {
                    'repo': bug['repo'],
                    'base_commit': bug['base_commit'],
                    'problem_statement': bug['problem_statement'],
                    'patch': bug['patch'],
                }
            }
            os.makedirs('results/locagent_verified_small', exist_ok=True)
            with open('results/locagent_verified_small/loc_outputs.jsonl', 'a') as f:
                f.write(json.dumps(output) + '\n')
            print(f"\nOutput saved to results/locagent_verified_small/loc_outputs.jsonl")
            reset_current_issue()
            print("Done!")
            sys.exit(0)

        elif action.action_type == ActionType.MESSAGE:
            print(f"Message: {action.content[:100]}...")
            messages.append({"role": "user", "content": fake_user_msg})

        elif action.action_type == ActionType.RUN_IPYTHON:
            from util.runtime.execute_ipython import execute_ipython
            code = action.code.strip('`')
            print(f"Executing code ({len(code)} chars)...")
            try:
                result = execute_ipython(code)
                print(f"Result: {result[:300] if result else 'EMPTY'}")
                messages.append({"role": "user", "content": f"OBSERVATION:\n{result}"})
            except Exception as e:
                print(f"Execution error: {e}")
                messages.append({"role": "user", "content": f"Execution error: {e}"})
        else:
            print(f"Unknown action type: {action.action_type}")

    time.sleep(1)

print("\n=== TIMEOUT ===")
reset_current_issue()
