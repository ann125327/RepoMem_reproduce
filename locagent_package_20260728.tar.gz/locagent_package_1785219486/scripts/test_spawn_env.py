"""Test env var inheritance in spawn subprocess."""
import torch.multiprocessing as mp
import os

def check_env(result_queue):
    print(f'Child ANTHROPIC_API_KEY: {os.environ.get("ANTHROPIC_API_KEY", "NOT SET")[:10]}...')
    print(f'Child ANTHROPIC_BASE_URL: {os.environ.get("ANTHROPIC_BASE_URL", "NOT SET")}')
    result_queue.put('ok')

if __name__ == '__main__':
    ctx = mp.get_context('spawn')
    q = ctx.Manager().Queue()
    p = ctx.Process(target=check_env, args=(q,))
    p.start()
    p.join(timeout=30)
    print(f'Parent exit code: {p.exitcode}')
    try:
        print(f'Result: {q.get_nowait()}')
    except:
        print('No result from child')
